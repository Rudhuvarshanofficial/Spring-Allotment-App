
package com.tnea.counselling.dto;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;

import java.util.List;

public record CollegeRequest(
        @NotBlank(message = "College name is required")
        String collegeName,

        @NotBlank(message = "College location is required")
        String collegeLocation,

        @NotEmpty(message = "At least one course is required")
        List<@Valid CourseRequest> course
) {
}
